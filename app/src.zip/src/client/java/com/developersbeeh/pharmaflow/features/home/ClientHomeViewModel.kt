package com.developersbeeh.pharmaflow.features.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.developersbeeh.pharmaflow.data.local.SessionManager
import com.developersbeeh.pharmaflow.data.model.Banner
import com.developersbeeh.pharmaflow.data.model.Product
import com.developersbeeh.pharmaflow.data.repository.MarketingRepository
import com.developersbeeh.pharmaflow.data.repository.ProductRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

@HiltViewModel
class ClientHomeViewModel
@Inject
constructor(
        private val productRepository: ProductRepository,
        private val marketingRepository: MarketingRepository,
        private val sessionManager: SessionManager
) : ViewModel() {

    // Expose current store for UI
    val storeState = sessionManager.currentStore

    private val _banners = MutableStateFlow<List<Banner>>(emptyList())
    val banners = _banners.asStateFlow()

    private val _featuredProducts = MutableStateFlow<List<Product>>(emptyList())
    val featuredProducts = _featuredProducts.asStateFlow()

    private val _featuredLoading = MutableStateFlow(true)
    val featuredLoading = _featuredLoading.asStateFlow()

    val categories =
            listOf(
                    "Todos",
                    "MEDICAMENTO",
                    "GENERICO",
                    "SIMILAR",
                    "ETICO",
                    "PERFUMARIA",
                    "CONVENIENCIA",
                    "VITAMINAS",
                    "SUPLEMENTOS",
                    "DERMOCOSMETICOS",
                    "CORRELATOS",
                    "FITOTERAPICO",
                    "HOMEOPATICO",
                    "NATURAIS",
                    "LIBERADO"
            )

    private val _selectedCategory = MutableStateFlow("Todos")
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    // Controle de Debounce para busca
    private var searchJob: Job? = null

    // PAGINAÇÃO PRINCIPAL
    @OptIn(ExperimentalCoroutinesApi::class)
    val pagedProducts: Flow<PagingData<Product>> =
            _selectedCategory
                    .flatMapLatest { category ->
                        // Quando a categoria muda, recriamos o fluxo de paginação
                        // Combinamos com a busca (que vem via callback, mas aqui vamos usar o
                        // parametro simples)
                        // Se a busca mudar, precisamos emitir de novo? Sim.
                        // O ideal seria um combine(_selectedCategory, _searchQuery)
                        // mas vamos simplificar:
                        kotlinx.coroutines.flow.combine(_searchQuery, _selectedCategory) {
                                query,
                                cat ->
                            Pair(query, cat)
                        }
                    }
                    .flatMapLatest { (query, cat) ->
                        val storeId = sessionManager.getCurrentStoreId()
                        if (storeId.isNotEmpty()) {
                            productRepository.getPagedProducts(
                                    storeId = storeId,
                                    query = query,
                                    category = cat,
                                    onlyActive = true
                            )
                        } else {
                            // Estado vazio seguro caso não tenha loja selected (login fresh)
                            kotlinx.coroutines.flow.emptyFlow()
                        }
                    }
                    .cachedIn(viewModelScope)

    init {
        loadInitialData()
    }

    fun loadInitialData() {
        viewModelScope.launch {
            val storeId = sessionManager.getCurrentStoreId()
            if (storeId.isNotEmpty()) {
                // 1. Banners
                val bannersRes = marketingRepository.getBanners(storeId)
                if (bannersRes.isSuccess) _banners.value = bannersRes.getOrDefault(emptyList())

                // 2. Featured (Top 10)
                _featuredLoading.value = true
                val featRes = productRepository.getFeaturedProducts(storeId)
                if (featRes.isSuccess) {
                    _featuredProducts.value = featRes.getOrDefault(emptyList())
                }
                _featuredLoading.value = false
            }
        }
    }

    fun onCategorySelected(category: String) {
        _selectedCategory.value = category
        // Ao clicar em categoria, limpamos a busca para trazer a gride da categoria completa
        if (_searchQuery.value.isNotEmpty()) {
            _searchQuery.value = ""
        }
    }

    fun onSearchQueryChanged(query: String) {
        searchJob?.cancel()
        searchJob =
                viewModelScope.launch {
                    delay(500) // Debounce maior para evitar queries excessivas no Firestore
                    _searchQuery.value = query
                    // Se buscar, reseta categoria pra Todos para buscar globalmente na loja?
                    // UX: Geralmente busca é global.
                    if (query.isNotEmpty() && _selectedCategory.value != "Todos") {
                        // Opção: Manter categoria ou resetar.
                        // Vamos manter a categoria se o user já selecionou uma.
                    }
                }
    }
}
