package com.developersbeeh.pharmaflow.data.repository

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.developersbeeh.pharmaflow.data.model.Product
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.coroutines.tasks.await

class ProductPagingSource(
        private val firestore: FirebaseFirestore,
        private val storeId: String,
        private val searchQuery: String,
        private val category: String,
        private val onlyActive: Boolean,
        private val filterLowStock: Boolean
) : PagingSource<QuerySnapshot, Product>() {

    override fun getRefreshKey(state: PagingState<QuerySnapshot, Product>): QuerySnapshot? {
        return null
    }

    override suspend fun load(
            params: LoadParams<QuerySnapshot>
    ): LoadResult<QuerySnapshot, Product> {
        return try {
            // Base Query: Filtra pela loja
            var query = firestore.collection("products").whereEqualTo("storeId", storeId).limit(20)

            // Filtro de Ativo (apenas se solicitado true)
            if (onlyActive) {
                query = query.whereEqualTo("isActive", true)
            }

            // Filtro de Categoria
            if (category != "Todos") {
                query = query.whereEqualTo("category", category)
            }

            // Filtro de Baixo Estoque (Server-side)
            if (filterLowStock) {
                // IMPORTANTE: Isso EXIGE um índice composto: storeId + stockQuantity
                query = query.whereLessThan("stockQuantity", 5)
                // Ao usar whereLessThan, a primeira ordenação OBRIGATORIAMENTE deve ser pelo campo
                // do filtro
                query = query.orderBy("stockQuantity", Query.Direction.ASCENDING)
            }

            // Lógica de Busca
            if (searchQuery.isNotEmpty()) {
                // Se for número, busca exata no EAN ou Código Interno
                if (searchQuery.all { it.isDigit() }) {
                    // Priorizamos EAN.
                    query = query.whereEqualTo("ean", searchQuery)
                } else {
                    // Busca por Nome (Case Sensitive no Firestore)
                    query =
                            query.whereGreaterThanOrEqualTo("name", searchQuery)
                                    .whereLessThanOrEqualTo("name", searchQuery + "\uf8ff")
                }
            } else {
                // Se não tem busca e nem filtro de range (lowStock), ordenamos por nome
                // Se lowStock estiver ativo, a ordenação primária já foi definida acima
                if (!filterLowStock) {
                    query = query.orderBy("name", Query.Direction.ASCENDING)
                } else {
                    // Se low stock tá ativo, podemos adicionar nome como critério secundário de
                    // desempate
                    query = query.orderBy("name", Query.Direction.ASCENDING)
                }
            }

            if (params.key != null) {
                query = query.startAfter(params.key!!.documents.last())
            }

            val currentPage = query.get().await()
            val products = currentPage.toObjects(Product::class.java)

            val nextKey = if (products.isEmpty()) null else currentPage

            LoadResult.Page(data = products, prevKey = null, nextKey = nextKey)
        } catch (e: Exception) {
            e.printStackTrace()
            LoadResult.Error(e)
        }
    }
}
