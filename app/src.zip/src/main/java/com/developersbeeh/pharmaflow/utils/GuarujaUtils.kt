package com.developersbeeh.pharmaflow.utils

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Utilitário responsável pela inteligência logística do Guarujá.
 * Mapeia Bairros -> Zonas -> Lojas.
 */
object GuarujaUtils {

    // IDs das Lojas (Devem coincidir com o Firestore)
    const val STORE_ID_ASTURIAS = "loja_01_asturias"
    const val STORE_ID_MORRINHOS = "loja_02_morrinhos"
    const val STORE_ID_STAROSA = "loja_03_starosa"
    const val STORE_ID_PEREQUE1 = "loja_04_pereque1"
    const val STORE_ID_PEREQUE2 = "loja_05_pereque2"

    // Zonas de Motoboy
    const val ZONE_WEST_CENTER = "zona_oeste_centro" // Grupo A (Astúrias/Centro)
    const val ZONE_EAST_PEREQUE = "zona_leste_pereque" // Grupo B (Perequê/Enseada Fundão)

    // Bairro -> Loja Responsável
    val neighborhoodMap = mapOf(
        // ZONA OESTE / CENTRO (Grupo A)
        "Astúrias" to STORE_ID_ASTURIAS,
        "Pitangueiras" to STORE_ID_ASTURIAS,
        "Tombo" to STORE_ID_ASTURIAS,
        "Guaiúba" to STORE_ID_ASTURIAS,
        "Jardim Las Palmas" to STORE_ID_ASTURIAS,
        "Vila Moisés" to STORE_ID_ASTURIAS,

        "Santa Rosa" to STORE_ID_STAROSA,
        "Santo Antônio" to STORE_ID_STAROSA,
        "Vila Lígia" to STORE_ID_STAROSA,
        "Jardim dos Pássaros" to STORE_ID_STAROSA,
        "Vicente de Carvalho" to STORE_ID_STAROSA,
        "Paecará" to STORE_ID_STAROSA,
        "Itapema" to STORE_ID_STAROSA,

        "Morrinhos" to STORE_ID_MORRINHOS,
        "Vila Zilda" to STORE_ID_MORRINHOS,
        "Cachoeira" to STORE_ID_MORRINHOS,
        "Vila Edna" to STORE_ID_MORRINHOS,

        // ZONA LESTE (Grupo B)
        "Perequê" to STORE_ID_PEREQUE1,
        "Jardim Acapulco" to STORE_ID_PEREQUE1,
        "Praia de Pernambuco" to STORE_ID_PEREQUE1,
        "Mar Casado" to STORE_ID_PEREQUE1,

        "Enseada" to STORE_ID_PEREQUE2,
        "Cidade Atlântica" to STORE_ID_PEREQUE2,
        "Jardim Virgínia" to STORE_ID_PEREQUE2,
        "Pedreira" to STORE_ID_PEREQUE2,
        "Vila Rã" to STORE_ID_PEREQUE2
    )

    // --- FUNÇÕES UTILITÁRIAS ---

    fun getNeighborhoods(): List<String> = neighborhoodMap.keys.sorted()

    fun getPreferredStore(neighborhood: String): String {
        return neighborhoodMap[neighborhood] ?: STORE_ID_ASTURIAS
    }

    // Qual zona esta loja pertence?
    fun getDeliveryZoneForStore(storeId: String): String {
        return when(storeId) {
            STORE_ID_ASTURIAS, STORE_ID_MORRINHOS, STORE_ID_STAROSA -> ZONE_WEST_CENTER
            STORE_ID_PEREQUE1, STORE_ID_PEREQUE2 -> ZONE_EAST_PEREQUE
            else -> ZONE_WEST_CENTER
        }
    }

    // NOVA FUNÇÃO: Retorna todas as lojas que um motoboy de certa zona pode atender
    fun getStoresByZone(zone: String): List<String> {
        return when (zone) {
            ZONE_WEST_CENTER -> listOf(STORE_ID_ASTURIAS, STORE_ID_MORRINHOS, STORE_ID_STAROSA)
            ZONE_EAST_PEREQUE -> listOf(STORE_ID_PEREQUE1, STORE_ID_PEREQUE2)
            else -> emptyList() // Motoboy sem zona definida não vê nada
        }
    }
}