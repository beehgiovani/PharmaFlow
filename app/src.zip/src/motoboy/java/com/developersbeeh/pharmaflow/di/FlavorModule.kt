package com.developersbeeh.pharmaflow.di

import com.developersbeeh.pharmaflow.ui.navigation.AppNavigator
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object FlavorModule {
    @Provides
    @Singleton
    fun provideNavigator(): AppNavigator = MotoboyNavigator()
}